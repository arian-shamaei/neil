#!/bin/sh
# email.sh -- Send email via SMTP
# Requires vault/email.key with format: smtp_host:port:user:password
VAULT="$HOME/.neil/services/vault/email.key"
if [ ! -f "$VAULT" ]; then
    echo "ERROR: no email credentials in vault" >&2
    exit 1
fi

TO="${NEIL_PARAM_to:?NOTIFY email channel requires to= param}"
SUBJECT="${NEIL_PARAM_subject:-Neil notification}"

# Read SMTP config
IFS=: read -r SMTP_HOST SMTP_PORT SMTP_USER SMTP_PASS < "$VAULT"

# Send via curl (works with most SMTP providers)
curl -s --ssl-reqd \
    --url "smtps://${SMTP_HOST}:${SMTP_PORT}" \
    --user "${SMTP_USER}:${SMTP_PASS}" \
    --mail-from "$SMTP_USER" \
    --mail-rcpt "$TO" \
    -T - << MAIL
From: Neil <$SMTP_USER>
To: $TO
Subject: $SUBJECT

$NEIL_MESSAGE
MAIL

# Clear credentials
unset SMTP_PASS
