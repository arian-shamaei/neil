#!/bin/sh
# slack.sh -- Post to Slack via incoming webhook
VAULT="$HOME/.neil/services/vault/slack.key"
if [ ! -f "$VAULT" ]; then
    echo "ERROR: no Slack webhook in vault" >&2
    exit 1
fi

WEBHOOK_URL=$(cat "$VAULT" | tr -d '\n')
ROOM="${NEIL_PARAM_room:-general}"

# Escape message for JSON
ESCAPED=$(echo "$NEIL_MESSAGE" | sed 's/\/\\/g; s/"/\\"/g; s/\n/\n/g')

curl -s -X POST "$WEBHOOK_URL" \
    -H 'Content-Type: application/json' \
    -d "{\"channel\":\"#${ROOM}\",\"text\":\"${ESCAPED}\"}"

unset WEBHOOK_URL
