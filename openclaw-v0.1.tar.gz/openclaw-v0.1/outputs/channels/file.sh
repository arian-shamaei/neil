#!/bin/sh
# file.sh -- Write message to a specified file
TARGET="${NEIL_PARAM_to:?NOTIFY file channel requires to= param}"
echo "$NEIL_MESSAGE" >> "$TARGET"
