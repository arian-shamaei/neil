#!/bin/sh
# terminal.sh -- Append message to neil.log
LOG="$HOME/.neil/outputs/neil.log"
echo "[$(date -Iseconds)] $NEIL_MESSAGE" >> "$LOG"
